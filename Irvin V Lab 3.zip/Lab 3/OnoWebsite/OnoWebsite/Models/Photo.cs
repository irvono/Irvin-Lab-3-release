﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OnoWebsite.Models
{
   public class Photo
    {
        public int PhotoID { get; set; }
        public string Name { get; set; }
        public int AlbumID { get; set; }

        public virtual ICollection<Album> Albums { get; set; }
    }
}
