﻿using OnoWebsite.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OnoWebsite.DAL
{
    public class OnoInitializer : System.Data.Entity.DropCreateDatabaseIfModelChanges<OnoContext>
    {
        protected override void Seed(OnoContext context)
        {
            var users = new List<User>
            {
                new User{LastName="Carson",FirstName="Alexander",Email="carsAlex@live.com", Skill="Photographer", Password="driveHonda240", Address="137 Olive st", Phone= 541-222-2222},
                new User{LastName="Hess",FirstName="Nate",Email="curlymustache@gmail.com", Skill="Graphic Design", Password="100klife", Address="9875 Ice Lake Dr", Phone= 606-852-5555},
                new User{LastName="Vargas",FirstName="Irvin",Email="vargasirvin@live.com", Skill="Videographer", Password="12iv0507zmz", Address="499 49th st", Phone= 541-555-5555}
            };
            users.ForEach(u => context.Users.Add(u));
            context.SaveChanges();

        }
    }
}
