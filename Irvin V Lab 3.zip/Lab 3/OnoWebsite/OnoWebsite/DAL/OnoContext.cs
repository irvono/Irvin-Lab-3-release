﻿using OnoWebsite.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.ModelConfiguration.Conventions;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OnoWebsite.DAL
{
    public class OnoContext: DbContext 
    {
          public OnoContext() : base("OnoContext")
        {
        }
        
        public DbSet<User> Users { get; set; }
        public DbSet<Album> Albums { get; set; }
        //public DbSet<Course> Courses { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Conventions.Remove<PluralizingTableNameConvention>();
        }
    }
}
