﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(OnoWebsite.Startup))]
namespace OnoWebsite
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
